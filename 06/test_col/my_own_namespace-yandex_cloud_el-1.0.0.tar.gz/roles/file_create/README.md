# my_own_namespace.yandex_cloud_el

Коллекция Ansible для (кратко: что делает).
Поддерживает: `ansible-core >= 2.13`.

## Установка
```bash
ansible-galaxy collection install git+https://github.com/<user>/<repo>.git,1.0.0
# или из архива:
# ansible-galaxy collection install ./my_own_namespace-yandex_cloud_el-1.0.0.tar.gz
